import Question from './Question';

class QuizController{
  constructor(questions=[], parentElement){
    this.questions = questions;
    this.parentElement = parentElement;
    this.convertedQuestions = this.questions.map((question)=>{
      return new Question(question, parentElement);
    });
    this.renderQuiz();
  }

  checkCorrect = () =>{
    console.log('check correct', this.convertedQuestions);
    for(let i = 0; i<this.convertedQuestions.length; i++){
      this.convertedQuestions[i].renderCheckResult();
    }
  }

  renderQuiz = () => {
    for(let i = 0; i<this.convertedQuestions.length; i++){
      this.convertedQuestions[i].renderQuestion();
    }
    const html = `<button id="check_button">Check Answers</button>`
    this.parentElement.insertAdjacentHTML('beforeend', html);
    document.querySelector('#check_button').addEventListener('click', this.checkCorrect);
  }


}

export default QuizController;
