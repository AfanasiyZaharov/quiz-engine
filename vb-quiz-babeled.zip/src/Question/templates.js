

export const validateErrorText = (rightAnswers) =>{
  return `right answer are ${rightAnswers.join(', ')}`;
}

export const questionTemplate = (questionData, id) => {
  console.log('id', id);
  return `
    <div class = "question" id="${id}">
      <div class="question-text">${questionData.questionText}</div>
      <div class="answer">
        ${answerTemplate(questionData)}
      </div>
    </div>
  `;
}

export const answerTemplate = (questionData) =>{
  if(questionData.questionType === 'simple-text' || questionData.questionType === 'text-in-blank'){
    return `
      <div class = "answer-text">
        <input class = "answer-text-input" />
      </div>
    `;
  }

  if(questionData.questionType === 'variants-single'){

    console.log(`      <form>
    <div>
      ${questionData.variants.map((value, index)=>`
        <input type="radio" id="${questionData.questionText}-${index}"
          name="${questionData.questionText}-${index}" value="${value}" />
        <label for="${questionData.questionText}-${index}">${value}</label>
      `).join(' ')}
    </div>
  </form>`);

    return `
      <form>
        <div>
          ${questionData.variants.map((value, index)=>`
            <input type="radio" id="${questionData.questionText}-${index}"
              name="${questionData.questionText}" value="${value}" />
            <label for="${questionData.questionText}-${index}">${value}</label>
          `).join(' ')}
        </div>
      </form>
    `;
  }

  if(questionData.questionType === 'variants-multi'){
    return `
      <form>
        <div>
          ${questionData.variants.map((value, index)=>`
            <input type="checkbox" id="${questionData.questionText}-${index}"
              name="${questionData.questionText}" value="${value}" />
            <label for="${questionData.questionText}-${index}">${value}</label>
          `).join(' ')}
        </div>
      </form>
    `;
  }
}
