
// fill it
const ShorteningDictionary = {
  'must not': `mustn't`, 
  'can not': `can't`, 
  'will not': `won't`, 
  ' is': `'s`,
  ' have': `'ve`,
  ' has': `'s`,
  ' would': `'d`,
  ' had': `'d`,
}

const compareTwo = (userAnswer, rightAnswer) =>{
  console.log('comparetwo', userAnswer, rightAnswer);
  let isValid = true;
  let workedUserAnswer = prepareString(userAnswer);
  console.log('wok', workedUserAnswer);
  let workedRightAnswer = prepareString(rightAnswer);
  return workedUserAnswer === workedRightAnswer;
}


// make trim, remove dot on the end, lowercase, ...etc
const prepareString = (answer) => {
  return answer.toLowerCase().replace(/\.$/, '').replace(/ +/g, ' ').replace(/ $/, '').replace(/^ /, '').replace(/\.$/, '');
}


export const validateSimpleText = (userAnswer, rightAnswers) =>{
  return rightAnswers.some((answer) => compareTwo(userAnswer, answer));
} 


let findShorteningsPossibilities = (userAnswer) =>{

  let textVariants = [];
  const shortSybmols = ['’', '\'', '`', '"'];
  for (let i = 0; i<shortSybmols.length; i++){
    let reg = new RegExp(shortSybmols[i], 'g');
    userAnswer = userAnswer.replace(reg, '\'');
  }
// for one shortening.

}

export const validateTextInBlank = (userAnswer, rightAnswers, questionText) =>{
  rightAnswers = [...rightAnswers, ...rightAnswers.map((rightAnswer)=> questionText.replace(/_+/g, rightAnswer))];
  return rightAnswers.some((answer) => compareTwo(userAnswer, answer));
}